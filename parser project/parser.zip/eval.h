//
//  eval.h
//  
//
//  Created by Ella Grady on 3/16/22.
//

#ifndef eval_h
#define eval_h
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser.h"

SExp eval(SExp expression);


#endif /* eval_h */
