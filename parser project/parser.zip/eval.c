//
//  eval.c
//  
//
//  Created by Ella Grady on 3/16/22.
// 
#include <stdlib.h>
#include <string.h>
#include "eval.h"
#include "parser.h"


SExp eval(SExp expression) {
    conscell pointercell = expression->pointer;
    if (pointercell == NULL)
        {
            return expression;
        }
        SExp tempexp;
        //exit
        if (!strcmp(pointercell->first->data, "exit"))
        {
            printf("Have a nice day!\n");
            printf("[MyMachine:cs170/Scheme]\n");
            exit(0);
        }
        // quote
        else if (!strcmp(pointercell->first->data, "quote"))
        {
            // check if input is list
            int n = 1;
            if (strcmp(expression->pointer->rest->data, ""))
            {
                n = 0;
            }
            // eval rest of list
            SExp restexp = makeexpression();
            restexp->pointer = pointercell->rest->first;
            tempexp = eval(restexp);
            
            // check if input is list
            if (n == 0)
            {
                list = 0;
            }
            else
            {
                list = 1;
            }
            return quote(tempexp);
        }
        //car function
        else if (!strcmp(pointercell->first->data, "car"))
        {
            //eval the rest of the list
            SExp restexp = makeexpression();
            restexp->pointer = pointercell->rest->first;
            tempexp = eval(restexp);
            //check if the car is a list
            if (strcmp(tempexp->pointer->data, ""))
            {
                list = 0;
            }
            return car(tempexp);
        }
        //cdr function
        else if (!strcmp(pointercell->first->data, "cdr"))
        {
            //eval the rest of the list
            SExp restexp = makeexpression();
            restexp->pointer = pointercell->rest->first;
            tempexp = eval(restexp);
            return cdr(tempexp);
        }
        //symbol? function
        else if (!strcmp(pointercell->first->data, "symbol?"))
        {
            //eval the rest of the list
            SExp restexp = makeexpression();
            restexp->pointer = pointercell->rest->first;
            tempexp = eval(restexp);
            //check if input is a list
            if (strcmp(tempexp->pointer->data, "") && tempexp->pointer->rest == NULL)
            {
                list = 0;
            }
            return symbol(tempexp);
        }
        //cons function
        else if (!strcmp(pointercell->first->data, "cons"))
        {
            //int i = 0;
            SExp restexp1 = makeexpression();
            restexp1->pointer = pointercell->rest->first;
            SExp expression1 = eval(restexp1);
            //if (list == 1)
            // {
               // i = 1;
                // list = 0;
            // }
            SExp restexp2 = makeexpression();
            restexp2->pointer = pointercell->rest->rest->first;
            SExp expression2 = eval(restexp2);
            return cons(expression1, expression2);
        }
    else{
        return expression;
            // if (strcmp(pointercell->data, "") && list == 0)
            // {
                
                /*if (strcmp(tempexp->pointer->data, "()"))
                {
                    SExp restexp = makeexpression();
                    restexp->pointer = pointercell->rest->first;
                    list = 1;
                    return restexp;
                }
                else
                {
                    return expression;
                }
            }
            else{
                return expression;
            }*/
        
    }
}
    
